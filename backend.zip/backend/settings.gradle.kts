rootProject.name = "bitplate-srms"
